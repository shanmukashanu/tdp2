import React, { useState } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import AIInsightBanner from './AIInsightBanner';
import {
  Users, FileText, BarChart3, Briefcase, MessageCircle, Shield, Bell,
  TrendingUp, TrendingDown, Eye, Trash2, Ban, CheckCircle, XCircle,
  Search, Filter, Download, RefreshCw, AlertTriangle, Activity
} from 'lucide-react';

const AdminDashboard: React.FC = () => {
  const { currentPage, blogs, polls, works, deleteBlog, updateWorkStatus, deleteWork } = useAppContext();
  const [activeTab, setActiveTab] = useState(currentPage === 'admin-dashboard' ? 'overview' : currentPage.replace('admin-', ''));

  const tabs = [
    { id: 'overview', label: 'Overview', icon: Activity },
    { id: 'users', label: 'Users', icon: Users },
    { id: 'blogs', label: 'Blogs', icon: FileText },
    { id: 'polls', label: 'Polls', icon: BarChart3 },
    { id: 'surveys', label: 'Surveys', icon: BarChart3 },
    { id: 'works', label: 'Works', icon: Briefcase },
    { id: 'groups', label: 'Groups', icon: Users },
    { id: 'alerts', label: 'Alerts', icon: Bell },
    { id: 'reports', label: 'Reports', icon: Shield },
    { id: 'chats', label: 'Chats', icon: MessageCircle },
  ];

  React.useEffect(() => {
    if (currentPage.startsWith('admin-')) {
      const tab = currentPage.replace('admin-', '');
      setActiveTab(tab === 'dashboard' ? 'overview' : tab);
    }
  }, [currentPage]);

  const stats = [
    { label: 'Total Users', value: '24,567', change: '+12.5%', up: true, icon: Users, color: 'from-blue-500 to-blue-600' },
    { label: 'Active Blogs', value: blogs.length.toString(), change: '+8.2%', up: true, icon: FileText, color: 'from-green-500 to-green-600' },
    { label: 'Poll Responses', value: polls.reduce((a, p) => a + p.totalVotes, 0).toLocaleString(), change: '+23.1%', up: true, icon: BarChart3, color: 'from-purple-500 to-purple-600' },
    { label: 'Open Works', value: works.filter(w => w.status === 'Open').length.toString(), change: '-5.3%', up: false, icon: Briefcase, color: 'from-orange-500 to-orange-600' },
    { label: 'Pending Reports', value: '7', change: '+2', up: true, icon: Shield, color: 'from-red-500 to-red-600' },
    { label: 'Active Chats', value: '1,234', change: '+15.7%', up: true, icon: MessageCircle, color: 'from-teal-500 to-teal-600' },
  ];

  const mockUsers = [
    { id: 'u1', name: 'Srinivas Rao', email: 'srinivas@email.com', role: 'user', status: 'active', joined: '2024-06-15', posts: 12 },
    { id: 'u2', name: 'Suresh Mohan', email: 'suresh@email.com', role: 'user', status: 'active', joined: '2022-03-15', posts: 45 },
    { id: 'u3', name: 'Anitha Reddy', email: 'anitha@email.com', role: 'moderator', status: 'active', joined: '2023-01-20', posts: 28 },
    { id: 'u4', name: 'Ravi Kumar', email: 'ravi@email.com', role: 'user', status: 'suspended', joined: '2024-06-10', posts: 3 },
    { id: 'u5', name: 'Padma Lakshmi', email: 'padma@email.com', role: 'user', status: 'active', joined: '2021-11-05', posts: 67 },
    { id: 'u6', name: 'Venkat Rao', email: 'venkat@email.com', role: 'user', status: 'active', joined: '2020-02-28', posts: 89 },
  ];

  const mockAlerts = [
    { id: 'a1', type: 'warning', message: 'High traffic detected on polls page', time: '5 min ago' },
    { id: 'a2', type: 'info', message: 'New user registrations up 25% this week', time: '1 hour ago' },
    { id: 'a3', type: 'error', message: '3 reports pending review for over 24 hours', time: '2 hours ago' },
    { id: 'a4', type: 'success', message: 'System backup completed successfully', time: '6 hours ago' },
    { id: 'a5', type: 'warning', message: 'Storage usage at 78% capacity', time: '1 day ago' },
  ];

  const mockReports = [
    { id: 'r1', type: 'Spam', reporter: 'Anitha R.', target: 'Unknown User', status: 'pending', date: '2026-02-08' },
    { id: 'r2', type: 'Harassment', reporter: 'Suresh M.', target: 'User456', status: 'reviewing', date: '2026-02-07' },
    { id: 'r3', type: 'Misinformation', reporter: 'Padma L.', target: 'BlogPost#234', status: 'resolved', date: '2026-02-06' },
    { id: 'r4', type: 'Impersonation', reporter: 'Venkat R.', target: 'FakeProfile', status: 'pending', date: '2026-02-06' },
  ];

  const renderOverview = () => (
    <div>
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        {stats.map((stat, i) => {
          const Icon = stat.icon;
          return (
            <div key={i} className="bg-white rounded-xl border border-gray-100 p-5 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between mb-3">
                <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${stat.color} flex items-center justify-center`}>
                  <Icon className="w-5 h-5 text-white" />
                </div>
                <span className={`flex items-center gap-1 text-xs font-bold ${stat.up ? 'text-green-600' : 'text-red-600'}`}>
                  {stat.up ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                  {stat.change}
                </span>
              </div>
              <p className="text-2xl font-black text-gray-900">{stat.value}</p>
              <p className="text-xs text-gray-500 mt-0.5">{stat.label}</p>
            </div>
          );
        })}
      </div>

      {/* Quick Actions */}
      <div className="bg-white rounded-xl border border-gray-100 p-5 shadow-sm mb-6">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Quick Actions</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[
            { label: 'Export Users', icon: Download, color: 'bg-blue-50 text-blue-600 hover:bg-blue-100' },
            { label: 'Send Alert', icon: Bell, color: 'bg-yellow-50 text-yellow-600 hover:bg-yellow-100' },
            { label: 'Review Reports', icon: Shield, color: 'bg-red-50 text-red-600 hover:bg-red-100' },
            { label: 'Refresh Data', icon: RefreshCw, color: 'bg-green-50 text-green-600 hover:bg-green-100' },
          ].map((action, i) => {
            const Icon = action.icon;
            return (
              <button key={i} className={`flex items-center gap-2 px-4 py-3 rounded-xl text-sm font-medium transition-colors ${action.color}`}>
                <Icon className="w-4 h-4" /> {action.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Recent Activity Chart Placeholder */}
      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl border border-gray-100 p-5 shadow-sm">
          <h3 className="text-sm font-bold text-gray-900 mb-4">User Growth (Last 7 Days)</h3>
          <div className="space-y-3">
            {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day, i) => {
              const width = [65, 72, 58, 80, 90, 95, 85][i];
              return (
                <div key={day} className="flex items-center gap-3">
                  <span className="text-xs text-gray-400 w-8">{day}</span>
                  <div className="flex-1 bg-gray-100 rounded-full h-2.5">
                    <div className="bg-gradient-to-r from-blue-500 to-blue-600 h-2.5 rounded-full transition-all duration-500" style={{ width: `${width}%` }} />
                  </div>
                  <span className="text-xs font-medium text-gray-600 w-8">{Math.round(width * 3.5)}</span>
                </div>
              );
            })}
          </div>
        </div>
        <div className="bg-white rounded-xl border border-gray-100 p-5 shadow-sm">
          <h3 className="text-sm font-bold text-gray-900 mb-4">Content Distribution</h3>
          <div className="space-y-4">
            {[
              { label: 'Blog Posts', count: blogs.length, total: 50, color: 'bg-blue-500' },
              { label: 'Active Polls', count: polls.length, total: 20, color: 'bg-green-500' },
              { label: 'Work Requests', count: works.length, total: 30, color: 'bg-orange-500' },
              { label: 'Groups', count: 8, total: 15, color: 'bg-purple-500' },
              { label: 'Reports', count: 4, total: 10, color: 'bg-red-500' },
            ].map(item => (
              <div key={item.label}>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-gray-600 font-medium">{item.label}</span>
                  <span className="text-gray-400">{item.count}/{item.total}</span>
                </div>
                <div className="bg-gray-100 rounded-full h-2">
                  <div className={`${item.color} h-2 rounded-full`} style={{ width: `${(item.count / item.total) * 100}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );

  const renderUsers = () => (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-bold text-gray-900">User Management</h3>
        <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700">
          <Download className="w-4 h-4" /> Export
        </button>
      </div>
      <div className="bg-white rounded-xl border border-gray-100 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-100">
              <tr>
                {['User', 'Email', 'Role', 'Status', 'Joined', 'Posts', 'Actions'].map(h => (
                  <th key={h} className="text-left px-4 py-3 text-xs font-bold text-gray-500 uppercase">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {mockUsers.map(u => (
                <tr key={u.id} className="border-b border-gray-50 hover:bg-gray-50">
                  <td className="px-4 py-3 text-sm font-medium text-gray-900">{u.name}</td>
                  <td className="px-4 py-3 text-sm text-gray-500">{u.email}</td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      u.role === 'moderator' ? 'bg-purple-100 text-purple-700' : 'bg-blue-100 text-blue-700'
                    }`}>{u.role}</span>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      u.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                    }`}>{u.status}</span>
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-500">{u.joined}</td>
                  <td className="px-4 py-3 text-sm text-gray-500">{u.posts}</td>
                  <td className="px-4 py-3">
                    <div className="flex gap-1">
                      <button className="p-1.5 hover:bg-gray-100 rounded-lg" title="View"><Eye className="w-3.5 h-3.5 text-gray-400" /></button>
                      <button className="p-1.5 hover:bg-red-50 rounded-lg" title="Ban"><Ban className="w-3.5 h-3.5 text-red-400" /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  const renderBlogs = () => (
    <div>
      <h3 className="text-lg font-bold text-gray-900 mb-4">Blog Management</h3>
      <div className="space-y-3">
        {blogs.map(blog => (
          <div key={blog.id} className="bg-white rounded-xl border border-gray-100 p-4 flex items-center justify-between shadow-sm">
            <div className="flex items-center gap-4 flex-1">
              {blog.image && <img src={blog.image} alt="" className="w-16 h-12 rounded-lg object-cover" />}
              <div>
                <h4 className="text-sm font-bold text-gray-900">{blog.title}</h4>
                <p className="text-xs text-gray-400">{blog.author} | {blog.date} | {blog.likes} likes | {blog.comments.length} comments</p>
              </div>
            </div>
            <div className="flex gap-2">
              <button className="p-2 hover:bg-gray-100 rounded-lg"><Eye className="w-4 h-4 text-gray-400" /></button>
              <button onClick={() => deleteBlog(blog.id)} className="p-2 hover:bg-red-50 rounded-lg"><Trash2 className="w-4 h-4 text-red-400" /></button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderWorks = () => (
    <div>
      <h3 className="text-lg font-bold text-gray-900 mb-4">Works Management</h3>
      <div className="space-y-3">
        {works.map(work => (
          <div key={work.id} className="bg-white rounded-xl border border-gray-100 p-4 flex items-center justify-between shadow-sm">
            <div className="flex-1">
              <h4 className="text-sm font-bold text-gray-900">{work.title}</h4>
              <p className="text-xs text-gray-400">{work.author} | {work.location} | {work.date}</p>
            </div>
            <div className="flex items-center gap-3">
              <select
                value={work.status}
                onChange={e => updateWorkStatus(work.id, e.target.value as any)}
                className="px-3 py-1.5 border border-gray-200 rounded-lg text-xs bg-white"
              >
                <option value="Open">Open</option>
                <option value="In Progress">In Progress</option>
                <option value="Found">Found</option>
                <option value="Completed">Completed</option>
              </select>
              <button onClick={() => deleteWork(work.id)} className="p-2 hover:bg-red-50 rounded-lg"><Trash2 className="w-4 h-4 text-red-400" /></button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderAlerts = () => (
    <div>
      <h3 className="text-lg font-bold text-gray-900 mb-4">System Alerts</h3>
      <div className="space-y-3">
        {mockAlerts.map(alert => (
          <div key={alert.id} className={`rounded-xl border p-4 flex items-start gap-3 ${
            alert.type === 'error' ? 'bg-red-50 border-red-200' :
            alert.type === 'warning' ? 'bg-yellow-50 border-yellow-200' :
            alert.type === 'success' ? 'bg-green-50 border-green-200' :
            'bg-blue-50 border-blue-200'
          }`}>
            <AlertTriangle className={`w-5 h-5 mt-0.5 ${
              alert.type === 'error' ? 'text-red-500' :
              alert.type === 'warning' ? 'text-yellow-500' :
              alert.type === 'success' ? 'text-green-500' :
              'text-blue-500'
            }`} />
            <div className="flex-1">
              <p className="text-sm font-medium text-gray-900">{alert.message}</p>
              <p className="text-xs text-gray-400 mt-1">{alert.time}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderReports = () => (
    <div>
      <h3 className="text-lg font-bold text-gray-900 mb-4">Report Management</h3>
      <div className="bg-white rounded-xl border border-gray-100 overflow-hidden shadow-sm">
        <table className="w-full">
          <thead className="bg-gray-50 border-b border-gray-100">
            <tr>
              {['Type', 'Reporter', 'Target', 'Status', 'Date', 'Actions'].map(h => (
                <th key={h} className="text-left px-4 py-3 text-xs font-bold text-gray-500 uppercase">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {mockReports.map(r => (
              <tr key={r.id} className="border-b border-gray-50 hover:bg-gray-50">
                <td className="px-4 py-3 text-sm font-medium text-gray-900">{r.type}</td>
                <td className="px-4 py-3 text-sm text-gray-500">{r.reporter}</td>
                <td className="px-4 py-3 text-sm text-gray-500">{r.target}</td>
                <td className="px-4 py-3">
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                    r.status === 'pending' ? 'bg-yellow-100 text-yellow-700' :
                    r.status === 'reviewing' ? 'bg-blue-100 text-blue-700' :
                    'bg-green-100 text-green-700'
                  }`}>{r.status}</span>
                </td>
                <td className="px-4 py-3 text-sm text-gray-500">{r.date}</td>
                <td className="px-4 py-3">
                  <div className="flex gap-1">
                    <button className="p-1.5 hover:bg-green-50 rounded-lg" title="Resolve"><CheckCircle className="w-3.5 h-3.5 text-green-500" /></button>
                    <button className="p-1.5 hover:bg-red-50 rounded-lg" title="Dismiss"><XCircle className="w-3.5 h-3.5 text-red-500" /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderContent = () => {
    switch (activeTab) {
      case 'overview': case 'dashboard': return renderOverview();
      case 'users': return renderUsers();
      case 'blogs': return renderBlogs();
      case 'works': return renderWorks();
      case 'alerts': return renderAlerts();
      case 'reports': return renderReports();
      case 'polls': return <div className="text-center py-12"><BarChart3 className="w-12 h-12 text-gray-300 mx-auto mb-3" /><p className="text-gray-500 font-medium">Poll Analytics</p><p className="text-sm text-gray-400">Total responses: {polls.reduce((a, p) => a + p.totalVotes, 0).toLocaleString()}</p></div>;
      case 'surveys': return <div className="text-center py-12"><BarChart3 className="w-12 h-12 text-gray-300 mx-auto mb-3" /><p className="text-gray-500 font-medium">Survey Analytics Dashboard</p><p className="text-sm text-gray-400">Manage and analyze survey responses</p></div>;
      case 'groups': return <div className="text-center py-12"><Users className="w-12 h-12 text-gray-300 mx-auto mb-3" /><p className="text-gray-500 font-medium">Group Management</p><p className="text-sm text-gray-400">8 active groups across the platform</p></div>;
      case 'chats': return <div className="text-center py-12"><MessageCircle className="w-12 h-12 text-gray-300 mx-auto mb-3" /><p className="text-gray-500 font-medium">Chat Monitoring</p><p className="text-sm text-gray-400">1,234 active conversations</p></div>;
      default: return renderOverview();
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="mb-6">
        <h1 className="text-3xl font-black text-gray-900">Admin Dashboard</h1>
        <p className="text-gray-500 mt-1">Manage platform content, users, and analytics</p>
      </div>

      <AIInsightBanner text="Data analytics and moderation help leadership take informed actions. Real-time insights enable proactive governance and community management." />

      {/* Tabs */}
      <div className="flex gap-1 mb-6 overflow-x-auto pb-2 -mx-4 px-4">
        {tabs.map(tab => {
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
                activeTab === tab.id
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              <Icon className="w-3.5 h-3.5" /> {tab.label}
            </button>
          );
        })}
      </div>

      {renderContent()}
    </div>
  );
};

export default AdminDashboard;
