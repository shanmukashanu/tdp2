import React, { useState } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import AIInsightBanner from './AIInsightBanner';
import {
  Heart, MessageCircle, Share2, Trash2, Plus, X, Image, Video, Send,
  Search, Filter, Calendar, ChevronDown, Upload, Eye
} from 'lucide-react';

const BlogsPage: React.FC = () => {
  const { blogs, addBlog, likeBlog, addComment, deleteBlog, user, isAuthenticated, setShowLoginModal } = useAppContext();
  const [showCreate, setShowCreate] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newContent, setNewContent] = useState('');
  const [newCategory, setNewCategory] = useState('General');
  const [newImage, setNewImage] = useState('');
  const [previewImage, setPreviewImage] = useState('');
  const [commentText, setCommentText] = useState<Record<string, string>>({});
  const [showComments, setShowComments] = useState<Record<string, boolean>>({});
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState('All');
  const [expandedBlog, setExpandedBlog] = useState<string | null>(null);

  const categories = ['All', 'Technology', 'Development', 'Employment', 'Healthcare', 'Education', 'Empowerment', 'General'];

  const filteredBlogs = blogs.filter(b => {
    const matchSearch = b.title.toLowerCase().includes(searchQuery.toLowerCase()) || b.content.toLowerCase().includes(searchQuery.toLowerCase());
    const matchCategory = filterCategory === 'All' || b.category === filterCategory;
    return matchSearch && matchCategory;
  });

  const handleCreate = () => {
    if (!newTitle.trim() || !newContent.trim()) return;
    addBlog({
      title: newTitle,
      content: newContent,
      author: user?.name || 'Anonymous',
      authorAvatar: user?.avatar || 'AN',
      image: previewImage || undefined,
      category: newCategory,
    });
    setNewTitle('');
    setNewContent('');
    setPreviewImage('');
    setNewImage('');
    setShowCreate(false);
  };

  const handleImagePreview = () => {
    if (newImage) {
      setPreviewImage(newImage);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-3xl font-black text-gray-900">Blogs & News</h1>
          <p className="text-gray-500 mt-1">Stay informed with the latest party updates and discussions</p>
        </div>
        {isAuthenticated && (
          <button
            onClick={() => setShowCreate(!showCreate)}
            className="flex items-center gap-2 px-5 py-2.5 bg-blue-600 text-white rounded-xl text-sm font-semibold hover:bg-blue-700 transition-colors shadow-md shadow-blue-200"
          >
            <Plus className="w-4 h-4" /> Create Post
          </button>
        )}
      </div>

      <AIInsightBanner text="Blog discussions help leadership understand public sentiment and emerging issues. Engage with posts to contribute to policy dialogue and democratic discourse." />

      {/* Create Blog Form */}
      {showCreate && (
        <div className="bg-white rounded-xl border border-gray-200 p-6 mb-8 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold text-gray-900">Create New Post</h3>
            <button onClick={() => setShowCreate(false)} className="p-1 hover:bg-gray-100 rounded-lg">
              <X className="w-5 h-5 text-gray-400" />
            </button>
          </div>
          <div className="space-y-4">
            <input
              type="text"
              value={newTitle}
              onChange={e => setNewTitle(e.target.value)}
              placeholder="Post title..."
              className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none"
            />
            <textarea
              value={newContent}
              onChange={e => setNewContent(e.target.value)}
              placeholder="Write your post content..."
              rows={5}
              className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none resize-none"
            />
            <div className="flex flex-wrap gap-3">
              <select
                value={newCategory}
                onChange={e => setNewCategory(e.target.value)}
                className="px-4 py-2 border border-gray-200 rounded-xl text-sm focus:border-blue-500 outline-none"
              >
                {categories.filter(c => c !== 'All').map(c => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
              <div className="flex items-center gap-2 flex-1 min-w-[200px]">
                <input
                  type="text"
                  value={newImage}
                  onChange={e => setNewImage(e.target.value)}
                  placeholder="Image URL (or Cloudinary upload)"
                  className="flex-1 px-4 py-2 border border-gray-200 rounded-xl text-sm focus:border-blue-500 outline-none"
                />
                <button onClick={handleImagePreview} className="p-2 bg-gray-100 rounded-xl hover:bg-gray-200 transition-colors">
                  <Eye className="w-4 h-4 text-gray-600" />
                </button>
              </div>
            </div>
            {/* Media upload buttons */}
            <div className="flex items-center gap-3">
              <button className="flex items-center gap-2 px-3 py-2 bg-gray-50 rounded-lg text-xs font-medium text-gray-600 hover:bg-gray-100 transition-colors border border-gray-200">
                <Image className="w-4 h-4" /> Photo
              </button>
              <button className="flex items-center gap-2 px-3 py-2 bg-gray-50 rounded-lg text-xs font-medium text-gray-600 hover:bg-gray-100 transition-colors border border-gray-200">
                <Video className="w-4 h-4" /> Video
              </button>
              <button className="flex items-center gap-2 px-3 py-2 bg-gray-50 rounded-lg text-xs font-medium text-gray-600 hover:bg-gray-100 transition-colors border border-gray-200">
                <Upload className="w-4 h-4" /> GIF
              </button>
            </div>
            {previewImage && (
              <div className="relative">
                <img src={previewImage} alt="Preview" className="w-full max-h-48 object-cover rounded-xl" />
                <button onClick={() => setPreviewImage('')} className="absolute top-2 right-2 p-1 bg-black/50 rounded-full">
                  <X className="w-4 h-4 text-white" />
                </button>
              </div>
            )}
            <button
              onClick={handleCreate}
              disabled={!newTitle.trim() || !newContent.trim()}
              className="px-6 py-2.5 bg-blue-600 text-white rounded-xl text-sm font-semibold hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Publish Post
            </button>
          </div>
        </div>
      )}

      {/* Search & Filter */}
      <div className="flex flex-col md:flex-row gap-3 mb-8">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search blogs..."
            className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none"
          />
        </div>
        <div className="flex gap-2 flex-wrap">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setFilterCategory(cat)}
              className={`px-4 py-2 rounded-xl text-xs font-medium transition-all ${
                filterCategory === cat
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Blog Grid */}
      <div className="grid md:grid-cols-2 gap-6">
        {filteredBlogs.map(blog => (
          <div key={blog.id} className="bg-white rounded-xl border border-gray-100 overflow-hidden shadow-sm hover:shadow-md transition-shadow">
            {blog.image && (
              <div className="relative h-52 overflow-hidden">
                <img src={blog.image} alt={blog.title} className="w-full h-full object-cover" />
                <span className="absolute top-3 left-3 px-3 py-1 bg-blue-600 text-white text-xs font-bold rounded-full">
                  {blog.category}
                </span>
              </div>
            )}
            <div className="p-5">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-9 h-9 rounded-full bg-gradient-to-br from-blue-500 to-blue-700 flex items-center justify-center text-white text-xs font-bold">
                  {blog.authorAvatar}
                </div>
                <div>
                  <p className="text-sm font-semibold text-gray-900">{blog.author}</p>
                  <p className="text-xs text-gray-400 flex items-center gap-1">
                    <Calendar className="w-3 h-3" /> {blog.date}
                  </p>
                </div>
                {user?.role === 'admin' && (
                  <button
                    onClick={() => deleteBlog(blog.id)}
                    className="ml-auto p-2 text-red-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                    title="Delete post"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2 leading-snug">{blog.title}</h3>
              <p className="text-sm text-gray-600 leading-relaxed mb-4">
                {expandedBlog === blog.id ? blog.content : blog.content.substring(0, 150) + '...'}
                <button
                  onClick={() => setExpandedBlog(expandedBlog === blog.id ? null : blog.id)}
                  className="text-blue-600 font-medium ml-1 hover:underline"
                >
                  {expandedBlog === blog.id ? 'Show less' : 'Read more'}
                </button>
              </p>

              {/* Actions */}
              <div className="flex items-center gap-4 pt-3 border-t border-gray-100">
                <button
                  onClick={() => isAuthenticated ? likeBlog(blog.id) : setShowLoginModal(true)}
                  className={`flex items-center gap-1.5 text-sm font-medium transition-colors ${
                    blog.liked ? 'text-red-500' : 'text-gray-400 hover:text-red-500'
                  }`}
                >
                  <Heart className={`w-4 h-4 ${blog.liked ? 'fill-current' : ''}`} />
                  {blog.likes}
                </button>
                <button
                  onClick={() => setShowComments(prev => ({ ...prev, [blog.id]: !prev[blog.id] }))}
                  className="flex items-center gap-1.5 text-sm font-medium text-gray-400 hover:text-blue-500 transition-colors"
                >
                  <MessageCircle className="w-4 h-4" />
                  {blog.comments.length}
                </button>
                <button className="flex items-center gap-1.5 text-sm font-medium text-gray-400 hover:text-green-500 transition-colors">
                  <Share2 className="w-4 h-4" />
                  Share
                </button>
              </div>

              {/* Comments */}
              {showComments[blog.id] && (
                <div className="mt-4 pt-4 border-t border-gray-100">
                  <div className="space-y-3 max-h-48 overflow-y-auto mb-3">
                    {blog.comments.length === 0 && (
                      <p className="text-xs text-gray-400 text-center py-2">No comments yet. Be the first!</p>
                    )}
                    {blog.comments.map(comment => (
                      <div key={comment.id} className="flex gap-2">
                        <div className="w-7 h-7 rounded-full bg-gray-200 flex items-center justify-center text-[10px] font-bold text-gray-600 flex-shrink-0">
                          {comment.author.charAt(0)}
                        </div>
                        <div className="bg-gray-50 rounded-lg px-3 py-2 flex-1">
                          <p className="text-xs font-semibold text-gray-700">{comment.author}</p>
                          <p className="text-xs text-gray-600">{comment.text}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                  {isAuthenticated && (
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={commentText[blog.id] || ''}
                        onChange={e => setCommentText(prev => ({ ...prev, [blog.id]: e.target.value }))}
                        placeholder="Write a comment..."
                        className="flex-1 px-3 py-2 border border-gray-200 rounded-lg text-xs focus:border-blue-500 outline-none"
                        onKeyDown={e => {
                          if (e.key === 'Enter' && commentText[blog.id]?.trim()) {
                            addComment(blog.id, commentText[blog.id]);
                            setCommentText(prev => ({ ...prev, [blog.id]: '' }));
                          }
                        }}
                      />
                      <button
                        onClick={() => {
                          if (commentText[blog.id]?.trim()) {
                            addComment(blog.id, commentText[blog.id]);
                            setCommentText(prev => ({ ...prev, [blog.id]: '' }));
                          }
                        }}
                        className="p-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                      >
                        <Send className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {filteredBlogs.length === 0 && (
        <div className="text-center py-16">
          <FileText className="w-12 h-12 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500 font-medium">No blogs found</p>
          <p className="text-sm text-gray-400">Try adjusting your search or filters</p>
        </div>
      )}
    </div>
  );
};

const FileText = ({ className }: { className?: string }) => (
  <svg className={className} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"/>
    <polyline points="14 2 14 8 20 8"/>
    <line x1="16" x2="8" y1="13" y2="13"/>
    <line x1="16" x2="8" y1="17" y2="17"/>
    <line x1="10" x2="8" y1="9" y2="9"/>
  </svg>
);

export default BlogsPage;
