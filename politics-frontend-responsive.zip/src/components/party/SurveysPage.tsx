import React, { useState } from 'react';
import AIInsightBanner from './AIInsightBanner';
import { ClipboardList, CheckCircle, Clock, ArrowRight, Send, ChevronDown, ChevronUp } from 'lucide-react';

interface Survey {
  id: string;
  title: string;
  description: string;
  questions: {
    id: string;
    text: string;
    type: 'mcq' | 'text' | 'rating';
    options?: string[];
  }[];
  deadline: string;
  responses: number;
  completed: boolean;
}

const SurveysPage: React.FC = () => {
  const [surveys] = useState<Survey[]>([
    {
      id: 's1', title: 'Public Infrastructure Satisfaction Survey',
      description: 'Help us understand your satisfaction with current infrastructure development in your area.',
      questions: [
        { id: 'q1', text: 'How would you rate the road conditions in your area?', type: 'mcq', options: ['Excellent', 'Good', 'Average', 'Poor', 'Very Poor'] },
        { id: 'q2', text: 'How satisfied are you with water supply?', type: 'mcq', options: ['Very Satisfied', 'Satisfied', 'Neutral', 'Dissatisfied', 'Very Dissatisfied'] },
        { id: 'q3', text: 'What infrastructure improvement do you need most?', type: 'text' },
        { id: 'q4', text: 'Rate overall governance on a scale of 1-5', type: 'rating', options: ['1', '2', '3', '4', '5'] },
      ],
      deadline: '2026-03-15', responses: 2847, completed: false
    },
    {
      id: 's2', title: 'Healthcare Access & Quality Feedback',
      description: 'Share your experience with government healthcare facilities and services.',
      questions: [
        { id: 'q5', text: 'How often do you visit government hospitals?', type: 'mcq', options: ['Weekly', 'Monthly', 'Quarterly', 'Rarely', 'Never'] },
        { id: 'q6', text: 'Rate the quality of medical staff', type: 'rating', options: ['1', '2', '3', '4', '5'] },
        { id: 'q7', text: 'What improvements would you suggest?', type: 'text' },
      ],
      deadline: '2026-03-20', responses: 1923, completed: false
    },
    {
      id: 's3', title: 'Education System Evaluation',
      description: 'Provide feedback on government school education quality and digital learning initiatives.',
      questions: [
        { id: 'q8', text: 'Do your children attend government schools?', type: 'mcq', options: ['Yes', 'No', 'Some do'] },
        { id: 'q9', text: 'Rate digital learning facilities', type: 'rating', options: ['1', '2', '3', '4', '5'] },
        { id: 'q10', text: 'What changes would improve education?', type: 'text' },
      ],
      deadline: '2026-02-28', responses: 3156, completed: true
    },
    {
      id: 's4', title: 'Youth Employment & Skill Development',
      description: 'Help us design better employment programs for the youth of our state.',
      questions: [
        { id: 'q11', text: 'What is your current employment status?', type: 'mcq', options: ['Employed', 'Self-employed', 'Student', 'Unemployed', 'Retired'] },
        { id: 'q12', text: 'Which skill training would benefit you most?', type: 'mcq', options: ['IT & Software', 'Healthcare', 'Agriculture', 'Manufacturing', 'Entrepreneurship'] },
        { id: 'q13', text: 'Share your ideas for job creation', type: 'text' },
      ],
      deadline: '2026-04-01', responses: 4521, completed: false
    },
  ]);

  const [activeSurvey, setActiveSurvey] = useState<string | null>(null);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState<Record<string, boolean>>({});

  const handleAnswer = (questionId: string, value: string) => {
    setAnswers(prev => ({ ...prev, [questionId]: value }));
  };

  const handleSubmit = (surveyId: string) => {
    setSubmitted(prev => ({ ...prev, [surveyId]: true }));
    setActiveSurvey(null);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="mb-6">
        <h1 className="text-3xl font-black text-gray-900">Surveys</h1>
        <p className="text-gray-500 mt-1">Share your feedback to help improve governance and services</p>
      </div>

      <AIInsightBanner text="Surveys collect structured feedback to improve policy and governance. Your responses directly influence decision-making and resource allocation priorities." />

      {/* Survey Stats */}
      <div className="grid grid-cols-3 gap-4 mb-8">
        <div className="bg-white rounded-xl border border-gray-100 p-5 shadow-sm text-center">
          <p className="text-2xl font-black text-blue-600">{surveys.length}</p>
          <p className="text-xs text-gray-500 mt-1">Total Surveys</p>
        </div>
        <div className="bg-white rounded-xl border border-gray-100 p-5 shadow-sm text-center">
          <p className="text-2xl font-black text-green-600">{surveys.reduce((a, s) => a + s.responses, 0).toLocaleString()}</p>
          <p className="text-xs text-gray-500 mt-1">Total Responses</p>
        </div>
        <div className="bg-white rounded-xl border border-gray-100 p-5 shadow-sm text-center">
          <p className="text-2xl font-black text-yellow-600">{surveys.filter(s => !s.completed).length}</p>
          <p className="text-xs text-gray-500 mt-1">Active Surveys</p>
        </div>
      </div>

      {/* Survey List */}
      <div className="space-y-4">
        {surveys.map(survey => (
          <div key={survey.id} className={`bg-white rounded-xl border overflow-hidden transition-all ${
            submitted[survey.id] || survey.completed ? 'border-green-200' : 'border-gray-100 hover:shadow-md'
          }`}>
            <div className="p-6">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                      submitted[survey.id] || survey.completed
                        ? 'bg-green-100 text-green-700'
                        : 'bg-blue-100 text-blue-700'
                    }`}>
                      {submitted[survey.id] || survey.completed ? 'Completed' : 'Active'}
                    </span>
                    <span className="text-xs text-gray-400 flex items-center gap-1">
                      <Clock className="w-3 h-3" /> Due: {survey.deadline}
                    </span>
                  </div>
                  <h3 className="text-lg font-bold text-gray-900 mb-1">{survey.title}</h3>
                  <p className="text-sm text-gray-500">{survey.description}</p>
                  <div className="flex items-center gap-4 mt-3">
                    <span className="text-xs text-gray-400">{survey.questions.length} questions</span>
                    <span className="text-xs text-gray-400">{survey.responses.toLocaleString()} responses</span>
                  </div>
                </div>
                <button
                  onClick={() => setActiveSurvey(activeSurvey === survey.id ? null : survey.id)}
                  disabled={submitted[survey.id] || survey.completed}
                  className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold transition-all ${
                    submitted[survey.id] || survey.completed
                      ? 'bg-green-50 text-green-600 cursor-default'
                      : 'bg-blue-600 text-white hover:bg-blue-700 shadow-md'
                  }`}
                >
                  {submitted[survey.id] || survey.completed ? (
                    <><CheckCircle className="w-4 h-4" /> Done</>
                  ) : activeSurvey === survey.id ? (
                    <><ChevronUp className="w-4 h-4" /> Close</>
                  ) : (
                    <><ArrowRight className="w-4 h-4" /> Take Survey</>
                  )}
                </button>
              </div>
            </div>

            {/* Survey Questions */}
            {activeSurvey === survey.id && !submitted[survey.id] && !survey.completed && (
              <div className="border-t border-gray-100 p-6 bg-gray-50">
                <div className="space-y-6">
                  {survey.questions.map((q, qi) => (
                    <div key={q.id} className="bg-white rounded-xl p-5 border border-gray-100">
                      <p className="text-sm font-semibold text-gray-900 mb-3">
                        <span className="text-blue-600 mr-2">Q{qi + 1}.</span>
                        {q.text}
                      </p>

                      {q.type === 'mcq' && q.options && (
                        <div className="space-y-2">
                          {q.options.map(opt => (
                            <button
                              key={opt}
                              onClick={() => handleAnswer(q.id, opt)}
                              className={`w-full text-left px-4 py-2.5 rounded-lg border-2 text-sm transition-all ${
                                answers[q.id] === opt
                                  ? 'border-blue-500 bg-blue-50 text-blue-700 font-medium'
                                  : 'border-gray-200 hover:border-blue-200 text-gray-600'
                              }`}
                            >
                              <div className="flex items-center gap-3">
                                <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                                  answers[q.id] === opt ? 'border-blue-500' : 'border-gray-300'
                                }`}>
                                  {answers[q.id] === opt && <div className="w-2 h-2 rounded-full bg-blue-500" />}
                                </div>
                                {opt}
                              </div>
                            </button>
                          ))}
                        </div>
                      )}

                      {q.type === 'text' && (
                        <textarea
                          value={answers[q.id] || ''}
                          onChange={e => handleAnswer(q.id, e.target.value)}
                          placeholder="Type your answer..."
                          rows={3}
                          className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none resize-none"
                        />
                      )}

                      {q.type === 'rating' && q.options && (
                        <div className="flex gap-3">
                          {q.options.map(opt => (
                            <button
                              key={opt}
                              onClick={() => handleAnswer(q.id, opt)}
                              className={`w-12 h-12 rounded-xl border-2 text-sm font-bold transition-all ${
                                answers[q.id] === opt
                                  ? 'border-blue-500 bg-blue-500 text-white shadow-md'
                                  : 'border-gray-200 text-gray-600 hover:border-blue-300'
                              }`}
                            >
                              {opt}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                <button
                  onClick={() => handleSubmit(survey.id)}
                  className="mt-6 flex items-center gap-2 px-8 py-3 bg-blue-600 text-white rounded-xl text-sm font-bold hover:bg-blue-700 transition-colors shadow-lg shadow-blue-200"
                >
                  <Send className="w-4 h-4" /> Submit Survey
                </button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default SurveysPage;
