import React, { useState } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import AIInsightBanner from './AIInsightBanner';
import { Users, MapPin, MessageCircle, Search, Plus, X, LogIn, LogOut, Lock, Globe } from 'lucide-react';

interface Group {
  id: string;
  name: string;
  description: string;
  members: number;
  category: string;
  location: string;
  type: 'public' | 'private';
  joined: boolean;
  image: string;
  admin: string;
}

const GroupsPage: React.FC = () => {
  const { isAuthenticated, setShowLoginModal, setCurrentPage } = useAppContext();
  const [groups, setGroups] = useState<Group[]>([
    { id: 'g1', name: 'Vijayawada District Committee', description: 'Official committee for Vijayawada district party activities, meetings, and coordination.', members: 1245, category: 'District', location: 'Vijayawada', type: 'public', joined: true, image: 'https://images.unsplash.com/photo-1529107386315-e1a2ed48a620?w=400', admin: 'Suresh M.' },
    { id: 'g2', name: 'Youth Wing AP', description: 'State-level youth wing for organizing events, campaigns, and youth empowerment programs.', members: 8934, category: 'Youth', location: 'Andhra Pradesh', type: 'public', joined: false, image: 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?w=400', admin: 'Anitha R.' },
    { id: 'g3', name: 'Women Empowerment Cell', description: 'Dedicated to women empowerment initiatives, self-help groups, and gender equality advocacy.', members: 5678, category: 'Women', location: 'State-wide', type: 'public', joined: true, image: 'https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?w=400', admin: 'Padma L.' },
    { id: 'g4', name: 'IT & Social Media Cell', description: 'Managing digital presence, social media campaigns, and technology initiatives for the party.', members: 3456, category: 'Technology', location: 'Hyderabad', type: 'private', joined: false, image: 'https://images.unsplash.com/photo-1504384308090-c894fdcc538d?w=400', admin: 'Rajesh N.' },
    { id: 'g5', name: 'Farmers Support Network', description: 'Supporting farmers with information on subsidies, market prices, and agricultural best practices.', members: 12345, category: 'Agriculture', location: 'Rural AP', type: 'public', joined: false, image: 'https://images.unsplash.com/photo-1500937386664-56d1dfef3854?w=400', admin: 'Ganesh B.' },
    { id: 'g6', name: 'Legal Aid Committee', description: 'Providing legal assistance and guidance to party members and citizens in need.', members: 890, category: 'Legal', location: 'State-wide', type: 'private', joined: false, image: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=400', admin: 'Anil V.' },
    { id: 'g7', name: 'Education Reform Task Force', description: 'Working on education policy recommendations and school improvement initiatives.', members: 2345, category: 'Education', location: 'State-wide', type: 'public', joined: true, image: 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=400', admin: 'Prof. Anand' },
    { id: 'g8', name: 'Guntur District Forum', description: 'District-level forum for Guntur constituency activities and local governance issues.', members: 987, category: 'District', location: 'Guntur', type: 'public', joined: false, image: 'https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?w=400', admin: 'Venkat R.' },
  ]);

  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState('All');
  const [showCreate, setShowCreate] = useState(false);
  const [newGroup, setNewGroup] = useState({ name: '', description: '', category: 'General', location: '', type: 'public' as const });

  const categories = ['All', 'District', 'Youth', 'Women', 'Technology', 'Agriculture', 'Legal', 'Education', 'General'];

  const filteredGroups = groups.filter(g => {
    const matchSearch = g.name.toLowerCase().includes(searchQuery.toLowerCase()) || g.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchCategory = filterCategory === 'All' || g.category === filterCategory;
    return matchSearch && matchCategory;
  });

  const toggleJoin = (id: string) => {
    if (!isAuthenticated) { setShowLoginModal(true); return; }
    setGroups(prev => prev.map(g =>
      g.id === id ? { ...g, joined: !g.joined, members: g.joined ? g.members - 1 : g.members + 1 } : g
    ));
  };

  const handleCreate = () => {
    if (!newGroup.name.trim()) return;
    const group: Group = {
      id: 'g' + Date.now(), ...newGroup, members: 1, joined: true,
      image: 'https://images.unsplash.com/photo-1529107386315-e1a2ed48a620?w=400', admin: 'You'
    };
    setGroups(prev => [group, ...prev]);
    setNewGroup({ name: '', description: '', category: 'General', location: '', type: 'public' });
    setShowCreate(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-3xl font-black text-gray-900">Groups</h1>
          <p className="text-gray-500 mt-1">Join groups to collaborate on local and social issues</p>
        </div>
        {isAuthenticated && (
          <button onClick={() => setShowCreate(!showCreate)} className="flex items-center gap-2 px-5 py-2.5 bg-blue-600 text-white rounded-xl text-sm font-semibold hover:bg-blue-700 transition-colors shadow-md">
            <Plus className="w-4 h-4" /> Create Group
          </button>
        )}
      </div>

      <AIInsightBanner text="Groups enable focused collaboration on local and social issues. Organized teams amplify impact and create structured channels for community action." />

      {showCreate && (
        <div className="bg-white rounded-xl border border-gray-200 p-6 mb-8 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold">Create New Group</h3>
            <button onClick={() => setShowCreate(false)} className="p-1 hover:bg-gray-100 rounded-lg"><X className="w-5 h-5 text-gray-400" /></button>
          </div>
          <div className="grid md:grid-cols-2 gap-4">
            <input type="text" value={newGroup.name} onChange={e => setNewGroup(p => ({ ...p, name: e.target.value }))} placeholder="Group name..." className="px-4 py-3 border border-gray-200 rounded-xl text-sm focus:border-blue-500 outline-none" />
            <input type="text" value={newGroup.location} onChange={e => setNewGroup(p => ({ ...p, location: e.target.value }))} placeholder="Location..." className="px-4 py-3 border border-gray-200 rounded-xl text-sm focus:border-blue-500 outline-none" />
            <select value={newGroup.category} onChange={e => setNewGroup(p => ({ ...p, category: e.target.value }))} className="px-4 py-3 border border-gray-200 rounded-xl text-sm bg-white">
              {categories.filter(c => c !== 'All').map(c => <option key={c} value={c}>{c}</option>)}
            </select>
            <select value={newGroup.type} onChange={e => setNewGroup(p => ({ ...p, type: e.target.value as any }))} className="px-4 py-3 border border-gray-200 rounded-xl text-sm bg-white">
              <option value="public">Public</option>
              <option value="private">Private</option>
            </select>
          </div>
          <textarea value={newGroup.description} onChange={e => setNewGroup(p => ({ ...p, description: e.target.value }))} placeholder="Group description..." rows={3} className="w-full mt-4 px-4 py-3 border border-gray-200 rounded-xl text-sm focus:border-blue-500 outline-none resize-none" />
          <button onClick={handleCreate} disabled={!newGroup.name.trim()} className="mt-4 px-6 py-2.5 bg-blue-600 text-white rounded-xl text-sm font-semibold hover:bg-blue-700 disabled:opacity-50">Create Group</button>
        </div>
      )}

      {/* Search & Filter */}
      <div className="flex flex-col md:flex-row gap-3 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input type="text" value={searchQuery} onChange={e => setSearchQuery(e.target.value)} placeholder="Search groups..." className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:border-blue-500 outline-none" />
        </div>
        <div className="flex gap-2 flex-wrap">
          {categories.slice(0, 6).map(cat => (
            <button key={cat} onClick={() => setFilterCategory(cat)} className={`px-3 py-2 rounded-xl text-xs font-medium ${filterCategory === cat ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}>
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Groups Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredGroups.map(group => (
          <div key={group.id} className="bg-white rounded-xl border border-gray-100 overflow-hidden hover:shadow-lg transition-all group/card">
            <div className="relative h-36 overflow-hidden">
              <img src={group.image} alt={group.name} className="w-full h-full object-cover group-hover/card:scale-105 transition-transform duration-500" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
              <div className="absolute bottom-3 left-3 right-3">
                <div className="flex items-center gap-2">
                  {group.type === 'private' ? (
                    <span className="flex items-center gap-1 px-2 py-0.5 bg-red-500/80 text-white rounded-full text-[10px] font-bold backdrop-blur-sm">
                      <Lock className="w-3 h-3" /> Private
                    </span>
                  ) : (
                    <span className="flex items-center gap-1 px-2 py-0.5 bg-green-500/80 text-white rounded-full text-[10px] font-bold backdrop-blur-sm">
                      <Globe className="w-3 h-3" /> Public
                    </span>
                  )}
                  <span className="px-2 py-0.5 bg-white/20 text-white rounded-full text-[10px] font-bold backdrop-blur-sm">{group.category}</span>
                </div>
              </div>
            </div>
            <div className="p-4">
              <h3 className="font-bold text-gray-900 mb-1">{group.name}</h3>
              <p className="text-xs text-gray-500 mb-3 line-clamp-2">{group.description}</p>
              <div className="flex items-center gap-3 text-xs text-gray-400 mb-4">
                <span className="flex items-center gap-1"><Users className="w-3 h-3" /> {group.members.toLocaleString()}</span>
                <span className="flex items-center gap-1"><MapPin className="w-3 h-3" /> {group.location}</span>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => toggleJoin(group.id)}
                  className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-semibold transition-all ${
                    group.joined
                      ? 'bg-gray-100 text-gray-700 hover:bg-red-50 hover:text-red-600'
                      : 'bg-blue-600 text-white hover:bg-blue-700'
                  }`}
                >
                  {group.joined ? <><LogOut className="w-3.5 h-3.5" /> Leave</> : <><LogIn className="w-3.5 h-3.5" /> Join</>}
                </button>
                {group.joined && (
                  <button
                    onClick={() => setCurrentPage('messages')}
                    className="px-4 py-2 bg-green-100 text-green-700 rounded-lg text-xs font-semibold hover:bg-green-200 transition-colors"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default GroupsPage;
