import React, { useState, useRef, useEffect } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import AIInsightBanner from './AIInsightBanner';
import {
  Send, Search, Image, Paperclip, Smile, Phone, Video, MoreVertical,
  Users, Globe, User, ArrowLeft, Hash
} from 'lucide-react';

const MessagesPage: React.FC = () => {
  const { chatRooms, activeChatRoom, setActiveChatRoom, sendMessage, user, isAuthenticated, setShowLoginModal } = useAppContext();
  const [messageInput, setMessageInput] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [showMobileChat, setShowMobileChat] = useState(false);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [activeChatRoom, chatRooms]);

  if (!isAuthenticated) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-8">
        <h1 className="text-3xl font-black text-gray-900 mb-4">Messages</h1>
        <AIInsightBanner text="Secure communication empowers coordination between members. Real-time messaging enables instant collaboration on party initiatives." />
        <div className="text-center py-20 bg-white rounded-xl border border-gray-100">
          <User className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-bold text-gray-900 mb-2">Sign in to access messages</h3>
          <p className="text-sm text-gray-500 mb-6">Connect with party members through secure messaging</p>
          <button onClick={() => setShowLoginModal(true)} className="px-6 py-3 bg-blue-600 text-white rounded-xl text-sm font-semibold hover:bg-blue-700 transition-colors">
            Sign In
          </button>
        </div>
      </div>
    );
  }

  const activeRoom = chatRooms.find(r => r.id === activeChatRoom);
  const filteredRooms = chatRooms.filter(r => r.name.toLowerCase().includes(searchQuery.toLowerCase()));

  const handleSend = () => {
    if (!messageInput.trim() || !activeChatRoom) return;
    sendMessage(activeChatRoom, messageInput);
    setMessageInput('');
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'community': return <Globe className="w-4 h-4" />;
      case 'group': return <Users className="w-4 h-4" />;
      default: return <User className="w-4 h-4" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'community': return 'from-green-500 to-green-600';
      case 'group': return 'from-purple-500 to-purple-600';
      default: return 'from-blue-500 to-blue-600';
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="mb-4">
        <h1 className="text-3xl font-black text-gray-900">Messages</h1>
      </div>
      <AIInsightBanner text="Secure communication empowers coordination between members. Real-time messaging enables instant collaboration on party initiatives and governance." />

      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden shadow-sm" style={{ height: '600px' }}>
        <div className="flex h-full">
          {/* Sidebar */}
          <div className={`w-full md:w-80 border-r border-gray-200 flex flex-col ${showMobileChat ? 'hidden md:flex' : 'flex'}`}>
            <div className="p-4 border-b border-gray-100">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                  placeholder="Search conversations..."
                  className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg text-sm focus:border-blue-500 outline-none"
                />
              </div>
            </div>
            <div className="flex-1 overflow-y-auto">
              {filteredRooms.map(room => (
                <button
                  key={room.id}
                  onClick={() => { setActiveChatRoom(room.id); setShowMobileChat(true); }}
                  className={`w-full flex items-center gap-3 px-4 py-3 hover:bg-gray-50 transition-colors border-b border-gray-50 ${
                    activeChatRoom === room.id ? 'bg-blue-50 border-l-2 border-l-blue-500' : ''
                  }`}
                >
                  <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${getTypeColor(room.type)} flex items-center justify-center text-white flex-shrink-0`}>
                    {getTypeIcon(room.type)}
                  </div>
                  <div className="flex-1 min-w-0 text-left">
                    <div className="flex items-center justify-between">
                      <h4 className="text-sm font-semibold text-gray-900 truncate">{room.name}</h4>
                      {room.unread > 0 && (
                        <span className="w-5 h-5 bg-blue-600 text-white text-[10px] font-bold rounded-full flex items-center justify-center flex-shrink-0">
                          {room.unread}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-gray-400 truncate">{room.lastMessage}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Chat Area */}
          <div className={`flex-1 flex flex-col ${!showMobileChat && !activeChatRoom ? 'hidden md:flex' : 'flex'}`}>
            {activeRoom ? (
              <>
                {/* Chat Header */}
                <div className="flex items-center justify-between px-5 py-3 border-b border-gray-100">
                  <div className="flex items-center gap-3">
                    <button onClick={() => setShowMobileChat(false)} className="md:hidden p-1">
                      <ArrowLeft className="w-5 h-5 text-gray-600" />
                    </button>
                    <div className={`w-9 h-9 rounded-lg bg-gradient-to-br ${getTypeColor(activeRoom.type)} flex items-center justify-center text-white`}>
                      {getTypeIcon(activeRoom.type)}
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-gray-900">{activeRoom.name}</h3>
                      <p className="text-[10px] text-gray-400 uppercase font-medium">{activeRoom.type} chat</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                      <Phone className="w-4 h-4 text-gray-400" />
                    </button>
                    <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                      <Video className="w-4 h-4 text-gray-400" />
                    </button>
                    <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                      <MoreVertical className="w-4 h-4 text-gray-400" />
                    </button>
                  </div>
                </div>

                {/* Messages */}
                <div className="flex-1 overflow-y-auto p-5 space-y-4 bg-gray-50">
                  {activeRoom.messages.map(msg => {
                    const isOwn = msg.senderId === user?.id;
                    return (
                      <div key={msg.id} className={`flex ${isOwn ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-[70%] ${isOwn ? 'order-1' : ''}`}>
                          {!isOwn && (
                            <p className="text-[10px] text-gray-400 font-medium mb-1 ml-1">{msg.senderName}</p>
                          )}
                          <div className={`px-4 py-2.5 rounded-2xl text-sm ${
                            isOwn
                              ? 'bg-blue-600 text-white rounded-br-md'
                              : 'bg-white text-gray-800 rounded-bl-md border border-gray-100 shadow-sm'
                          }`}>
                            {msg.text}
                          </div>
                          <p className={`text-[10px] text-gray-400 mt-1 ${isOwn ? 'text-right mr-1' : 'ml-1'}`}>
                            {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                  <div ref={messagesEndRef} />
                </div>

                {/* Input */}
                <div className="px-4 py-3 border-t border-gray-100 bg-white">
                  <div className="flex items-center gap-2">
                    <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                      <Paperclip className="w-4 h-4 text-gray-400" />
                    </button>
                    <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                      <Image className="w-4 h-4 text-gray-400" />
                    </button>
                    <input
                      type="text"
                      value={messageInput}
                      onChange={e => setMessageInput(e.target.value)}
                      onKeyDown={e => e.key === 'Enter' && handleSend()}
                      placeholder="Type a message..."
                      className="flex-1 px-4 py-2 border border-gray-200 rounded-xl text-sm focus:border-blue-500 outline-none"
                    />
                    <button className="p-2 hover:bg-gray-100 rounded-lg transition-colors">
                      <Smile className="w-4 h-4 text-gray-400" />
                    </button>
                    <button
                      onClick={handleSend}
                      disabled={!messageInput.trim()}
                      className="p-2.5 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors disabled:opacity-50"
                    >
                      <Send className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </>
            ) : (
              <div className="flex-1 flex items-center justify-center bg-gray-50">
                <div className="text-center">
                  <div className="w-20 h-20 rounded-2xl bg-gray-100 flex items-center justify-center mx-auto mb-4">
                    <Hash className="w-10 h-10 text-gray-300" />
                  </div>
                  <h3 className="text-lg font-bold text-gray-900 mb-1">Select a conversation</h3>
                  <p className="text-sm text-gray-500">Choose a chat from the sidebar to start messaging</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default MessagesPage;
