import React, { useState } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import AIInsightBanner from './AIInsightBanner';
import {
  MessageSquare, Heart, Share2, Pin, TrendingUp, Clock, Plus, X, Send,
  Users, Filter, Search
} from 'lucide-react';

interface Discussion {
  id: string;
  title: string;
  content: string;
  author: string;
  avatar: string;
  category: string;
  likes: number;
  liked: boolean;
  replies: number;
  pinned: boolean;
  date: string;
  views: number;
}

const CommunityPage: React.FC = () => {
  const { isAuthenticated, setShowLoginModal, user } = useAppContext();
  const [discussions, setDiscussions] = useState<Discussion[]>([
    { id: 'd1', title: 'Strategies for Upcoming Municipal Elections', content: 'Let us discuss our approach for the upcoming municipal elections. What key issues should we focus on to connect with voters?', author: 'Rajesh K.', avatar: 'RK', category: 'Elections', likes: 45, liked: false, replies: 23, pinned: true, date: '2 hours ago', views: 567 },
    { id: 'd2', title: 'Digital Literacy Campaign - Volunteers Needed', content: 'We are launching a digital literacy campaign across rural areas. Looking for volunteers who can teach basic computer skills.', author: 'Priya S.', avatar: 'PS', category: 'Volunteering', likes: 32, liked: false, replies: 15, pinned: true, date: '5 hours ago', views: 342 },
    { id: 'd3', title: 'Water Crisis in Rayalaseema Region', content: 'The ongoing water crisis needs immediate attention. What solutions can we propose to the government for long-term water management?', author: 'Venkat R.', avatar: 'VR', category: 'Issues', likes: 78, liked: false, replies: 41, pinned: false, date: '1 day ago', views: 1203 },
    { id: 'd4', title: 'Youth Wing Monthly Meetup - February 2026', content: 'Join us for the monthly youth wing meetup. Topics include career guidance, skill development, and community service planning.', author: 'Anitha M.', avatar: 'AM', category: 'Events', likes: 21, liked: false, replies: 8, pinned: false, date: '1 day ago', views: 189 },
    { id: 'd5', title: 'Success Story: Road Development in Nellore District', content: 'Sharing the progress of road development projects in Nellore. Over 200km of new roads completed in the last quarter!', author: 'Suresh B.', avatar: 'SB', category: 'Success Stories', likes: 156, liked: false, replies: 34, pinned: false, date: '2 days ago', views: 2341 },
    { id: 'd6', title: 'Feedback on New Education Policy Implementation', content: 'How is the new education policy being implemented in your area? Share your observations and suggestions for improvement.', author: 'Lakshmi D.', avatar: 'LD', category: 'Policy', likes: 43, liked: false, replies: 19, pinned: false, date: '3 days ago', views: 678 },
    { id: 'd7', title: 'Farmer Support Programs - What More Can We Do?', content: 'Our farmer support programs have helped thousands, but there is always room for improvement. Share your ideas.', author: 'Ganesh P.', avatar: 'GP', category: 'Agriculture', likes: 89, liked: false, replies: 52, pinned: false, date: '3 days ago', views: 1567 },
    { id: 'd8', title: 'Women Empowerment Workshop Series', content: 'Announcing a series of workshops focused on women empowerment, financial literacy, and entrepreneurship development.', author: 'Kavitha N.', avatar: 'KN', category: 'Empowerment', likes: 67, liked: false, replies: 28, pinned: false, date: '4 days ago', views: 890 },
  ]);

  const [showCreate, setShowCreate] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newContent, setNewContent] = useState('');
  const [newCategory, setNewCategory] = useState('General');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState('All');
  const [sortBy, setSortBy] = useState<'latest' | 'popular'>('latest');

  const categories = ['All', 'Elections', 'Volunteering', 'Issues', 'Events', 'Success Stories', 'Policy', 'Agriculture', 'Empowerment', 'General'];

  const filteredDiscussions = discussions
    .filter(d => {
      const matchSearch = d.title.toLowerCase().includes(searchQuery.toLowerCase());
      const matchCategory = filterCategory === 'All' || d.category === filterCategory;
      return matchSearch && matchCategory;
    })
    .sort((a, b) => {
      if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
      if (sortBy === 'popular') return b.likes - a.likes;
      return 0;
    });

  const handleLike = (id: string) => {
    if (!isAuthenticated) { setShowLoginModal(true); return; }
    setDiscussions(prev => prev.map(d =>
      d.id === id ? { ...d, liked: !d.liked, likes: d.liked ? d.likes - 1 : d.likes + 1 } : d
    ));
  };

  const handleCreate = () => {
    if (!newTitle.trim() || !newContent.trim()) return;
    const newDiscussion: Discussion = {
      id: 'd' + Date.now(), title: newTitle, content: newContent,
      author: user?.name || 'Anonymous', avatar: user?.avatar || 'AN',
      category: newCategory, likes: 0, liked: false, replies: 0,
      pinned: false, date: 'Just now', views: 0
    };
    setDiscussions(prev => [newDiscussion, ...prev]);
    setNewTitle('');
    setNewContent('');
    setShowCreate(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-3xl font-black text-gray-900">Community Forum</h1>
          <p className="text-gray-500 mt-1">Discuss, debate, and collaborate on issues that matter</p>
        </div>
        {isAuthenticated && (
          <button onClick={() => setShowCreate(!showCreate)} className="flex items-center gap-2 px-5 py-2.5 bg-blue-600 text-white rounded-xl text-sm font-semibold hover:bg-blue-700 transition-colors shadow-md">
            <Plus className="w-4 h-4" /> New Discussion
          </button>
        )}
      </div>

      <AIInsightBanner text="Community discussions unify voices across regions. Open dialogue strengthens party unity and helps identify grassroots issues that need attention." />

      {showCreate && (
        <div className="bg-white rounded-xl border border-gray-200 p-6 mb-8 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold">Start a Discussion</h3>
            <button onClick={() => setShowCreate(false)} className="p-1 hover:bg-gray-100 rounded-lg"><X className="w-5 h-5 text-gray-400" /></button>
          </div>
          <input type="text" value={newTitle} onChange={e => setNewTitle(e.target.value)} placeholder="Discussion title..." className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm mb-3 focus:border-blue-500 outline-none" />
          <textarea value={newContent} onChange={e => setNewContent(e.target.value)} placeholder="Share your thoughts..." rows={4} className="w-full px-4 py-3 border border-gray-200 rounded-xl text-sm mb-3 focus:border-blue-500 outline-none resize-none" />
          <div className="flex items-center gap-3">
            <select value={newCategory} onChange={e => setNewCategory(e.target.value)} className="px-4 py-2 border border-gray-200 rounded-xl text-sm bg-white">
              {categories.filter(c => c !== 'All').map(c => <option key={c} value={c}>{c}</option>)}
            </select>
            <button onClick={handleCreate} disabled={!newTitle.trim()} className="px-6 py-2 bg-blue-600 text-white rounded-xl text-sm font-semibold hover:bg-blue-700 disabled:opacity-50">Post Discussion</button>
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="flex flex-col md:flex-row gap-3 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input type="text" value={searchQuery} onChange={e => setSearchQuery(e.target.value)} placeholder="Search discussions..." className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:border-blue-500 outline-none" />
        </div>
        <div className="flex gap-2">
          <button onClick={() => setSortBy('latest')} className={`px-4 py-2 rounded-xl text-xs font-medium ${sortBy === 'latest' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600'}`}>
            <Clock className="w-3 h-3 inline mr-1" /> Latest
          </button>
          <button onClick={() => setSortBy('popular')} className={`px-4 py-2 rounded-xl text-xs font-medium ${sortBy === 'popular' ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600'}`}>
            <TrendingUp className="w-3 h-3 inline mr-1" /> Popular
          </button>
        </div>
      </div>

      <div className="flex gap-2 mb-6 flex-wrap">
        {categories.map(cat => (
          <button key={cat} onClick={() => setFilterCategory(cat)} className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${filterCategory === cat ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}>
            {cat}
          </button>
        ))}
      </div>

      {/* Discussions */}
      <div className="space-y-3">
        {filteredDiscussions.map(d => (
          <div key={d.id} className={`bg-white rounded-xl border p-5 hover:shadow-md transition-all ${d.pinned ? 'border-yellow-200 bg-yellow-50/30' : 'border-gray-100'}`}>
            <div className="flex items-start gap-4">
              <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-blue-500 to-blue-700 flex items-center justify-center text-white text-sm font-bold flex-shrink-0">
                {d.avatar}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1 flex-wrap">
                  {d.pinned && (
                    <span className="flex items-center gap-1 px-2 py-0.5 bg-yellow-100 text-yellow-700 rounded-full text-[10px] font-bold">
                      <Pin className="w-3 h-3" /> Pinned
                    </span>
                  )}
                  <span className="px-2 py-0.5 bg-gray-100 text-gray-600 rounded-full text-[10px] font-bold">{d.category}</span>
                </div>
                <h3 className="text-base font-bold text-gray-900 mb-1">{d.title}</h3>
                <p className="text-sm text-gray-600 mb-3 line-clamp-2">{d.content}</p>
                <div className="flex items-center gap-4">
                  <span className="text-xs text-gray-400">{d.author}</span>
                  <span className="text-xs text-gray-400">{d.date}</span>
                  <span className="text-xs text-gray-400">{d.views} views</span>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-4 mt-4 pt-3 border-t border-gray-100">
              <button onClick={() => handleLike(d.id)} className={`flex items-center gap-1.5 text-sm font-medium transition-colors ${d.liked ? 'text-red-500' : 'text-gray-400 hover:text-red-500'}`}>
                <Heart className={`w-4 h-4 ${d.liked ? 'fill-current' : ''}`} /> {d.likes}
              </button>
              <button className="flex items-center gap-1.5 text-sm font-medium text-gray-400 hover:text-blue-500 transition-colors">
                <MessageSquare className="w-4 h-4" /> {d.replies} replies
              </button>
              <button className="flex items-center gap-1.5 text-sm font-medium text-gray-400 hover:text-green-500 transition-colors">
                <Share2 className="w-4 h-4" /> Share
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default CommunityPage;
