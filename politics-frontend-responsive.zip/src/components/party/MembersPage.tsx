import React, { useState } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import AIInsightBanner from './AIInsightBanner';
import { Search, MessageCircle, MapPin, Phone, Mail, X, Users, Filter, ChevronDown, Shield } from 'lucide-react';

interface Member {
  id: string;
  name: string;
  avatar: string;
  role: string;
  district: string;
  constituency: string;
  phone: string;
  email: string;
  joinedDate: string;
  status: 'active' | 'inactive';
  contributions: number;
}

const members: Member[] = [
  { id: 'u2', name: 'Suresh Mohan', avatar: 'SM', role: 'District Secretary', district: 'Krishna', constituency: 'Vijayawada East', phone: '+91 98765 11111', email: 'suresh@tdp.org', joinedDate: '2022-03-15', status: 'active', contributions: 156 },
  { id: 'u3', name: 'Anitha Reddy', avatar: 'AR', role: 'Youth Wing Leader', district: 'Guntur', constituency: 'Tenali', phone: '+91 98765 22222', email: 'anitha@tdp.org', joinedDate: '2023-01-20', status: 'active', contributions: 89 },
  { id: 'u4', name: 'Ravi Kumar', avatar: 'RK', role: 'Ward Member', district: 'Tirupati', constituency: 'Chandragiri', phone: '+91 98765 33333', email: 'ravi@tdp.org', joinedDate: '2024-06-10', status: 'active', contributions: 45 },
  { id: 'u5', name: 'Padma Lakshmi', avatar: 'PL', role: 'Women Wing President', district: 'Kakinada', constituency: 'Pithapuram', phone: '+91 98765 44444', email: 'padma@tdp.org', joinedDate: '2021-11-05', status: 'active', contributions: 234 },
  { id: 'u6', name: 'Venkat Rao', avatar: 'VR', role: 'Senior Leader', district: 'Nellore', constituency: 'Nellore City', phone: '+91 98765 55555', email: 'venkat@tdp.org', joinedDate: '2020-02-28', status: 'active', contributions: 312 },
  { id: 'u7', name: 'Lakshmi Devi', avatar: 'LD', role: 'Mandal President', district: 'Rajahmundry', constituency: 'Rajahmundry Urban', phone: '+91 98765 66666', email: 'lakshmi@tdp.org', joinedDate: '2023-07-14', status: 'active', contributions: 67 },
  { id: 'u8', name: 'Rajesh Naidu', avatar: 'RN', role: 'IT Cell Coordinator', district: 'Visakhapatnam', constituency: 'Gajuwaka', phone: '+91 98765 77777', email: 'rajesh@tdp.org', joinedDate: '2024-01-08', status: 'active', contributions: 198 },
  { id: 'u9', name: 'Sita Patel', avatar: 'SP', role: 'Booth Agent', district: 'Kurnool', constituency: 'Kurnool', phone: '+91 98765 88888', email: 'sita@tdp.org', joinedDate: '2025-03-22', status: 'active', contributions: 23 },
  { id: 'u10', name: 'Ganesh Babu', avatar: 'GB', role: 'Village President', district: 'Prakasam', constituency: 'Ongole', phone: '+91 98765 99999', email: 'ganesh@tdp.org', joinedDate: '2022-09-30', status: 'inactive', contributions: 78 },
  { id: 'u11', name: 'Priya Sharma', avatar: 'PS', role: 'Social Media Head', district: 'Anantapur', constituency: 'Anantapur Urban', phone: '+91 98765 00000', email: 'priya@tdp.org', joinedDate: '2024-04-18', status: 'active', contributions: 145 },
  { id: 'u12', name: 'Anil Varma', avatar: 'AV', role: 'Legal Advisor', district: 'Srikakulam', constituency: 'Srikakulam', phone: '+91 98765 12345', email: 'anil@tdp.org', joinedDate: '2021-06-01', status: 'active', contributions: 267 },
  { id: 'u13', name: 'Kavitha Prasad', avatar: 'KP', role: 'Treasurer', district: 'West Godavari', constituency: 'Eluru', phone: '+91 98765 67890', email: 'kavitha@tdp.org', joinedDate: '2023-12-15', status: 'active', contributions: 189 },
];

const MembersPage: React.FC = () => {
  const { setCurrentPage, isAuthenticated, setShowLoginModal } = useAppContext();
  const [searchQuery, setSearchQuery] = useState('');
  const [filterDistrict, setFilterDistrict] = useState('All');
  const [selectedMember, setSelectedMember] = useState<Member | null>(null);

  const districts = ['All', ...Array.from(new Set(members.map(m => m.district)))];

  const filteredMembers = members.filter(m => {
    const matchSearch = m.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.role.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.district.toLowerCase().includes(searchQuery.toLowerCase());
    const matchDistrict = filterDistrict === 'All' || m.district === filterDistrict;
    return matchSearch && matchDistrict;
  });

  const handleChat = (memberId: string) => {
    if (!isAuthenticated) { setShowLoginModal(true); return; }
    setCurrentPage('messages');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="mb-6">
        <h1 className="text-3xl font-black text-gray-900">Members Directory</h1>
        <p className="text-gray-500 mt-1">Connect with party members across all districts</p>
      </div>

      <AIInsightBanner text="Member networks strengthen grassroots leadership and collaboration. Building connections across districts creates a unified force for positive change." />

      {/* Search & Filter */}
      <div className="flex flex-col md:flex-row gap-3 mb-8">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search members by name, role, or district..."
            className="w-full pl-10 pr-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none"
          />
        </div>
        <select
          value={filterDistrict}
          onChange={e => setFilterDistrict(e.target.value)}
          className="px-4 py-2.5 border border-gray-200 rounded-xl text-sm focus:border-blue-500 outline-none bg-white"
        >
          {districts.map(d => (
            <option key={d} value={d}>{d === 'All' ? 'All Districts' : d}</option>
          ))}
        </select>
      </div>

      <p className="text-sm text-gray-500 mb-4">{filteredMembers.length} members found</p>

      {/* Members Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredMembers.map(member => (
          <div key={member.id} className="bg-white rounded-xl border border-gray-100 p-5 hover:shadow-md transition-all group">
            <div className="flex items-start gap-4">
              <div className={`w-14 h-14 rounded-xl flex items-center justify-center text-white text-lg font-bold shadow-md ${
                member.status === 'active'
                  ? 'bg-gradient-to-br from-blue-500 to-blue-700'
                  : 'bg-gradient-to-br from-gray-400 to-gray-500'
              }`}>
                {member.avatar}
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="font-bold text-gray-900 truncate">{member.name}</h3>
                <p className="text-xs text-blue-600 font-medium">{member.role}</p>
                <p className="text-xs text-gray-400 flex items-center gap-1 mt-1">
                  <MapPin className="w-3 h-3" /> {member.district} - {member.constituency}
                </p>
              </div>
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                member.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'
              }`}>
                {member.status}
              </span>
            </div>
            <div className="flex items-center gap-2 mt-4 pt-4 border-t border-gray-100">
              <button
                onClick={() => setSelectedMember(member)}
                className="flex-1 py-2 bg-gray-100 text-gray-700 rounded-lg text-xs font-medium hover:bg-gray-200 transition-colors"
              >
                View Profile
              </button>
              <button
                onClick={() => handleChat(member.id)}
                className="flex items-center gap-1.5 px-4 py-2 bg-blue-600 text-white rounded-lg text-xs font-medium hover:bg-blue-700 transition-colors"
              >
                <MessageCircle className="w-3.5 h-3.5" /> Chat
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Member Profile Modal */}
      {selectedMember && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setSelectedMember(null)} />
          <div className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl overflow-hidden">
            <div className="h-24 bg-gradient-to-r from-blue-600 to-blue-800 relative">
              <button onClick={() => setSelectedMember(null)} className="absolute top-3 right-3 p-1.5 bg-white/20 rounded-lg hover:bg-white/30 transition-colors">
                <X className="w-4 h-4 text-white" />
              </button>
            </div>
            <div className="px-6 pb-6">
              <div className="-mt-10 mb-4">
                <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-blue-500 to-blue-700 flex items-center justify-center text-white text-2xl font-bold border-4 border-white shadow-lg">
                  {selectedMember.avatar}
                </div>
              </div>
              <h2 className="text-xl font-bold text-gray-900">{selectedMember.name}</h2>
              <p className="text-sm text-blue-600 font-medium">{selectedMember.role}</p>

              <div className="mt-5 space-y-3">
                <div className="flex items-center gap-3 text-sm">
                  <MapPin className="w-4 h-4 text-gray-400" />
                  <span className="text-gray-600">{selectedMember.district} - {selectedMember.constituency}</span>
                </div>
                <div className="flex items-center gap-3 text-sm">
                  <Phone className="w-4 h-4 text-gray-400" />
                  <span className="text-gray-600">{selectedMember.phone}</span>
                </div>
                <div className="flex items-center gap-3 text-sm">
                  <Mail className="w-4 h-4 text-gray-400" />
                  <span className="text-gray-600">{selectedMember.email}</span>
                </div>
                <div className="flex items-center gap-3 text-sm">
                  <Shield className="w-4 h-4 text-gray-400" />
                  <span className="text-gray-600">Member since {selectedMember.joinedDate}</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 mt-5">
                <div className="bg-blue-50 rounded-xl p-3 text-center">
                  <p className="text-xl font-black text-blue-600">{selectedMember.contributions}</p>
                  <p className="text-xs text-gray-500">Contributions</p>
                </div>
                <div className="bg-green-50 rounded-xl p-3 text-center">
                  <p className="text-xl font-black text-green-600">{selectedMember.status === 'active' ? 'Active' : 'Inactive'}</p>
                  <p className="text-xs text-gray-500">Status</p>
                </div>
              </div>

              <button
                onClick={() => { handleChat(selectedMember.id); setSelectedMember(null); }}
                className="w-full mt-5 flex items-center justify-center gap-2 py-3 bg-blue-600 text-white rounded-xl text-sm font-semibold hover:bg-blue-700 transition-colors shadow-md"
              >
                <MessageCircle className="w-4 h-4" /> Send Message
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MembersPage;
