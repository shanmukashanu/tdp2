import React from 'react';
import { useAppContext } from '@/contexts/AppContext';
import AIInsightBanner from './AIInsightBanner';
import {
  ArrowRight, Users, BarChart3, FileText, Briefcase, Globe, Shield,
  TrendingUp, Award, Heart, Zap, Target, ChevronRight
} from 'lucide-react';

const HomePage: React.FC = () => {
  const { setCurrentPage, setShowLoginModal, isAuthenticated } = useAppContext();

  const stats = [
    { label: 'Active Members', value: '2.5M+', icon: Users, color: 'from-blue-500 to-blue-600' },
    { label: 'Districts Covered', value: '26', icon: Globe, color: 'from-green-500 to-green-600' },
    { label: 'Works Completed', value: '15K+', icon: Briefcase, color: 'from-yellow-500 to-orange-500' },
    { label: 'Polls Conducted', value: '850+', icon: BarChart3, color: 'from-purple-500 to-purple-600' },
  ];

  const features = [
    { title: 'Digital Democracy', desc: 'Participate in polls, surveys, and community discussions to shape party policies.', icon: BarChart3, color: 'bg-blue-50 text-blue-600', page: 'polls' },
    { title: 'Transparent Governance', desc: 'Track public works, view progress reports, and hold leaders accountable.', icon: Shield, color: 'bg-green-50 text-green-600', page: 'works' },
    { title: 'Community Voice', desc: 'Join community forums, group discussions, and share your ideas with leadership.', icon: Globe, color: 'bg-purple-50 text-purple-600', page: 'community' },
    { title: 'Member Network', desc: 'Connect with fellow party members, collaborate on initiatives, and grow together.', icon: Users, color: 'bg-orange-50 text-orange-600', page: 'members' },
    { title: 'News & Updates', desc: 'Stay informed with the latest party news, blog posts, and press releases.', icon: FileText, color: 'bg-red-50 text-red-600', page: 'blogs' },
    { title: 'Public Works', desc: 'Submit and track public work requests for your constituency and community.', icon: Briefcase, color: 'bg-teal-50 text-teal-600', page: 'works' },
  ];

  const newsItems = [
    { title: 'Party Wins 3 Key Municipal Elections', date: 'Feb 8, 2026', category: 'Elections', image: 'https://images.unsplash.com/photo-1540910419892-4a36d2c3266c?w=400' },
    { title: 'New Youth Wing Initiative Launched', date: 'Feb 7, 2026', category: 'Youth', image: 'https://images.unsplash.com/photo-1529107386315-e1a2ed48a620?w=400' },
    { title: 'Rural Development Fund Increased by 40%', date: 'Feb 6, 2026', category: 'Development', image: 'https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?w=400' },
    { title: 'Digital Literacy Program Reaches 1M Citizens', date: 'Feb 5, 2026', category: 'Technology', image: 'https://images.unsplash.com/photo-1503676260728-1c00da094a0b?w=400' },
  ];

  const leaders = [
    { name: 'N. Chandrababu Naidu', role: 'Party President', image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300' },
    { name: 'Nara Lokesh', role: 'National General Secretary', image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=300' },
    { name: 'K. Atchannaidu', role: 'State President', image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300' },
    { name: 'Pattabhi Ram', role: 'Senior Leader', image: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=300' },
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-blue-900 via-blue-800 to-blue-950 text-white">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-0 w-96 h-96 bg-yellow-400 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2" />
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-blue-400 rounded-full blur-3xl translate-x-1/2 translate-y-1/2" />
          <div className="absolute top-1/2 left-1/2 w-64 h-64 bg-yellow-300 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2" />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 py-20 lg:py-28">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-yellow-400/20 border border-yellow-400/30 rounded-full text-yellow-300 text-sm font-medium mb-6">
                <Zap className="w-4 h-4" />
                Empowering 2.5 Million Members
              </div>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-black leading-tight mb-6">
                Building a
                <span className="text-yellow-400"> Stronger</span>
                <br />
                Tomorrow,
                <span className="text-yellow-400"> Together</span>
              </h1>
              <p className="text-lg text-blue-200 leading-relaxed mb-8 max-w-xl">
                Join the digital revolution in democratic participation. Your voice matters in shaping policies, tracking governance, and building a transparent future for all citizens.
              </p>
              <div className="flex flex-wrap gap-4">
                <button
                  onClick={() => isAuthenticated ? setCurrentPage('community') : setShowLoginModal(true)}
                  className="flex items-center gap-2 px-8 py-4 bg-yellow-400 text-blue-900 rounded-xl text-sm font-bold hover:bg-yellow-300 transition-all shadow-lg shadow-yellow-400/30 hover:shadow-yellow-400/50 hover:-translate-y-0.5"
                >
                  {isAuthenticated ? 'Join Community' : 'Get Started'}
                  <ArrowRight className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setCurrentPage('works')}
                  className="flex items-center gap-2 px-8 py-4 bg-white/10 text-white border border-white/20 rounded-xl text-sm font-bold hover:bg-white/20 transition-all backdrop-blur-sm"
                >
                  View Public Works
                </button>
              </div>
            </div>
            <div className="hidden lg:block">
              <div className="relative">
                <div className="absolute -inset-4 bg-gradient-to-r from-yellow-400/20 to-blue-400/20 rounded-3xl blur-xl" />
                <img
                  src="https://images.unsplash.com/photo-1529107386315-e1a2ed48a620?w=600&h=400&fit=crop"
                  alt="Community gathering"
                  className="relative rounded-2xl shadow-2xl w-full object-cover h-[400px]"
                />
                <div className="absolute -bottom-6 -left-6 bg-white rounded-xl p-4 shadow-xl">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-lg bg-green-100 flex items-center justify-center">
                      <TrendingUp className="w-6 h-6 text-green-600" />
                    </div>
                    <div>
                      <p className="text-2xl font-black text-gray-900">94%</p>
                      <p className="text-xs text-gray-500">Member Satisfaction</p>
                    </div>
                  </div>
                </div>
                <div className="absolute -top-4 -right-4 bg-white rounded-xl p-4 shadow-xl">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-lg bg-yellow-100 flex items-center justify-center">
                      <Award className="w-6 h-6 text-yellow-600" />
                    </div>
                    <div>
                      <p className="text-2xl font-black text-gray-900">15K+</p>
                      <p className="text-xs text-gray-500">Works Completed</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="relative -mt-8 z-10 max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {stats.map((stat, i) => {
            const Icon = stat.icon;
            return (
              <div key={i} className="bg-white rounded-xl p-5 shadow-lg border border-gray-100 hover:shadow-xl transition-shadow">
                <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${stat.color} flex items-center justify-center mb-3`}>
                  <Icon className="w-5 h-5 text-white" />
                </div>
                <p className="text-2xl font-black text-gray-900">{stat.value}</p>
                <p className="text-sm text-gray-500">{stat.label}</p>
              </div>
            );
          })}
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4">
        <AIInsightBanner text="Strengthening democracy through digital participation, transparency, and direct citizen engagement. Our platform connects millions of members with leadership for collaborative governance." />
      </div>

      {/* Features */}
      <section className="max-w-7xl mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-black text-gray-900 mb-3">Platform Features</h2>
          <p className="text-gray-500 max-w-2xl mx-auto">Everything you need to participate in democratic governance and community building</p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, i) => {
            const Icon = feature.icon;
            return (
              <button
                key={i}
                onClick={() => setCurrentPage(feature.page)}
                className="text-left bg-white rounded-xl p-6 border border-gray-100 hover:border-blue-200 hover:shadow-lg transition-all group"
              >
                <div className={`w-12 h-12 rounded-xl ${feature.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                  <Icon className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2">{feature.title}</h3>
                <p className="text-sm text-gray-500 leading-relaxed">{feature.desc}</p>
                <div className="flex items-center gap-1 mt-4 text-blue-600 text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity">
                  Explore <ChevronRight className="w-4 h-4" />
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* Latest News */}
      <section className="bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between mb-10">
            <div>
              <h2 className="text-3xl font-black text-gray-900 mb-2">Latest News</h2>
              <p className="text-gray-500">Stay updated with party activities and achievements</p>
            </div>
            <button
              onClick={() => setCurrentPage('blogs')}
              className="hidden md:flex items-center gap-2 px-5 py-2.5 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors"
            >
              View All <ArrowRight className="w-4 h-4" />
            </button>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {newsItems.map((item, i) => (
              <button
                key={i}
                onClick={() => setCurrentPage('blogs')}
                className="text-left bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-lg transition-all group border border-gray-100"
              >
                <div className="relative h-48 overflow-hidden">
                  <img src={item.image} alt={item.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  <span className="absolute top-3 left-3 px-3 py-1 bg-blue-600 text-white text-xs font-bold rounded-full">
                    {item.category}
                  </span>
                </div>
                <div className="p-4">
                  <p className="text-xs text-gray-400 mb-2">{item.date}</p>
                  <h3 className="font-bold text-gray-900 leading-snug group-hover:text-blue-600 transition-colors">
                    {item.title}
                  </h3>
                </div>
              </button>
            ))}
          </div>
          <div className="md:hidden mt-6 text-center">
            <button
              onClick={() => setCurrentPage('blogs')}
              className="px-6 py-3 bg-blue-600 text-white rounded-lg text-sm font-medium"
            >
              View All News
            </button>
          </div>
        </div>
      </section>

      {/* Leadership */}
      <section className="max-w-7xl mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-black text-gray-900 mb-3">Party Leadership</h2>
          <p className="text-gray-500">Dedicated leaders working for the people</p>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          {leaders.map((leader, i) => (
            <div key={i} className="text-center group">
              <div className="relative w-32 h-32 mx-auto mb-4 rounded-full overflow-hidden border-4 border-yellow-400 shadow-lg group-hover:border-blue-500 transition-colors">
                <img src={leader.image} alt={leader.name} className="w-full h-full object-cover" />
              </div>
              <h3 className="font-bold text-gray-900">{leader.name}</h3>
              <p className="text-sm text-gray-500">{leader.role}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="bg-gradient-to-r from-yellow-400 to-yellow-500 py-16">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-black text-blue-900 mb-4">
            Ready to Make a Difference?
          </h2>
          <p className="text-blue-800/80 text-lg mb-8 max-w-2xl mx-auto">
            Join millions of citizens who are actively participating in building a better tomorrow through digital democracy.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <button
              onClick={() => isAuthenticated ? setCurrentPage('community') : setShowLoginModal(true)}
              className="px-8 py-4 bg-blue-900 text-white rounded-xl text-sm font-bold hover:bg-blue-800 transition-colors shadow-lg"
            >
              {isAuthenticated ? 'Go to Community' : 'Join Now - It\'s Free'}
            </button>
            <button
              onClick={() => setCurrentPage('contact')}
              className="px-8 py-4 bg-white text-blue-900 rounded-xl text-sm font-bold hover:bg-blue-50 transition-colors shadow-lg"
            >
              Contact Us
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
